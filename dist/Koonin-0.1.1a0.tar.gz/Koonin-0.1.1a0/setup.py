from setuptools import setup

setup(name='Koonin',
      version='0.1.1a',
      description="Koonin's Computational Physics",
      packages=['Koonin'],
      author='Sudhanva Lalit',
      author_email='sudsid@gmail.com',
      zip_safe=False)
